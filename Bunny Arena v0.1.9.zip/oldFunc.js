function openDepositModal() {
  let payment_ref = "", payment_amt = 0, screenshotUploaded = false;
  const modal = document.createElement('div');
  modal.classList.add('modal');

  const modalContent = document.createElement('div');
  modalContent.classList.add('modal-content');

  const modalHeader = document.createElement('div');
  modalHeader.classList.add('modal-header');

  const modalTitle = document.createElement('h2');
  modalTitle.textContent = 'Register';

  const closeBtn = document.createElement('button');
  closeBtn.classList.add('close-btn');
  closeBtn.textContent = '×';
  closeBtn.onclick = () => modal.classList.add("hidden");

  modalHeader.appendChild(modalTitle);
  modalHeader.appendChild(closeBtn);

  const modalBody = document.createElement('div');
  modalBody.classList.add('modal-body');

  const form = document.createElement('form');
  form.id = 'depositForm';

  // QR + Screenshot upload section
  const qrCard = document.createElement('div');
  qrCard.classList.add('qr-card');

  const qrImg = document.createElement('img');
  qrImg.src = '/UPI_QR.png';
  qrImg.alt = 'UPI QR';
  qrImg.classList.add('qr-img');
  qrImg.style.cursor = 'pointer';
  qrImg.onclick = () => {
    window.open(`upi://pay?pa=9395985348@postbank&pn=Bunny Arena&cu=INR&am=${tournament.entry_fee}`, "_blank");
  };

  const scanText = document.createElement('p');
  scanText.innerHTML = '<strong>Scan or click to Pay</strong>';

  const upiText = document.createElement('p');
  upiText.innerHTML = 'UPI ID: <span class="upi-id" id="upi-id">9395985348@postbank</span>';
  upiText.style.cursor = "pointer";
  upiText.onclick = () => {
    navigator.clipboard.writeText("9395985348@postbank");
    showAlert("UPI ID copied!", "success");
  };

  const label = document.createElement('label');
  label.textContent = 'Submit screenshot proof for payment';

  const ocrInput = document.createElement('input');
  ocrInput.type = 'file';
  ocrInput.accept = 'image/*';
  ocrInput.id = 'ocr-input';

  ocrInput.onchange = async () => {
    const file = ocrInput.files?.[0];
    if (!file) return;

    const fd = new FormData();
    fd.append("screenshot", file);

    try {
      showSpinner("Please wait...");
      const res = await fetchProtected("/ocr", {
        method: "POST",
        body: fd,
      });

      const result = await res.json();
      payment_ref = result.extracted.utr || "";
      payment_amt = result.extracted.amount || "";

      // Update payment info inputs with OCR result
      paymentRefInput.value = payment_ref;
      amountPaidInput.value = payment_amt;
      screenshotUploaded = true;

      showAlert("OCR Completed. Payment info updated.", "success");
    } catch (err) {
      console.error("OCR failed:", err);
      showAlert("OCR failed. Please try again.\n"+err, "error");
    } finally {
      hideSpinner();
    }
  };

  qrCard.appendChild(qrImg);
  qrCard.appendChild(scanText);
  qrCard.appendChild(upiText);
  qrCard.appendChild(label);
  qrCard.appendChild(ocrInput);

  // Payment info inputs
  const paymentRefInput = document.createElement('input');
  paymentRefInput.type = 'text';
  paymentRefInput.name = 'payment_ref';
  paymentRefInput.placeholder = 'Payment Reference';
  paymentRefInput.required = true;
  paymentRefInput.id = 'payment-ref';

  const amountPaidInput = document.createElement('input');
  amountPaidInput.type = 'number';
  amountPaidInput.name = 'amount_paid';
  amountPaidInput.step = '0.01';
  amountPaidInput.placeholder = 'Amount paid';
  amountPaidInput.required = true;
  amountPaidInput.id = 'payment-amt';

  const confirmCheckbox = document.createElement('input');
  confirmCheckbox.type = 'checkbox';
  confirmCheckbox.id = 'confirm-payment';
  confirmCheckbox.required = true;

  const confirmLabel = document.createElement('label');
  confirmLabel.setAttribute("for", "confirm-payment");
  confirmLabel.textContent = ' I confirm that the above payment information is correct.';


  // Submit button
  const submitBtn = document.createElement('button');
  submitBtn.type = 'submit';
  submitBtn.textContent = 'Register';

  form.appendChild(qrCard);
  form.appendChild(paymentRefInput);
  form.appendChild(amountPaidInput);
  form.appendChild(confirmCheckbox);
  form.appendChild(confirmLabel);
  if (!isSolo) form.appendChild(memberSection);
  form.appendChild(submitBtn);

  // Final submission
  form.onsubmit = async (e) => {
    e.preventDefault();

  if (!screenshotUploaded) {
    return showAlert("Please upload a valid payment screenshot first.", "error");
  }

  if (!confirmCheckbox.checked) {
    return showAlert("Please confirm the payment information.", "error");
  }

  if (parseFloat(amountPaidInput.value) !== parseFloat(tournament.entry_fee)) {
    return showAlert(`Amount paid must be exactly ₹${tournament.entry_fee}.`, "error");
  }


    const data = new FormData(form);
    const formDataEntries = Object.fromEntries(data.entries());

    const depositPayload = {
      payment_ref: formDataEntries.payment_ref,
      payment_amt: parseFloat(formDataEntries.amount_paid),
    };

    showSpinner();
    try {
      const res = await fetchProtected("wallet/deposit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(depositPayload)
      });

      const result = await res.json();

      if (!res.ok) return showAlert(result.message || "failed.", "error");

      showAlert("Deposited Successfully!", "success");
      modal.classList.add("hidden");
    } catch (err) {
      showAlert("Error: " + err.message, "error");
    } finally {
      hideSpinner();
    }
  };

  modalBody.appendChild(form);
  modalContent.appendChild(modalHeader);
  modalContent.appendChild(modalBody);
  modal.appendChild(modalContent);
  document.body.appendChild(modal);
}